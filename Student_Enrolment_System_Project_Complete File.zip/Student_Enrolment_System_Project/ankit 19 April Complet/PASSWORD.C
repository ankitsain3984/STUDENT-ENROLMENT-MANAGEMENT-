int  password()
{
	int i,p,a=0;
	char pass[10]={"12345"};
	char pass2[10];
	char num='0';
	//clrscr();
	//heading();
	printf("\n\tEnter the five digit password: ");
	for(i=0;i<5;i++)
	{
		num=getch();
		pass2[i]=num;
		printf("*");
	}
	pass2[i]='\0';
	if(strcmp(pass,pass2)==0)
	{
		getch();
		printf("\n\tlogin succeful.......\n");
		getch();
		a=1;

	}
	else
	{
		getch();
		printf("\n\tInvalid Password.......\n");
		getch();

	}

	return a;
}